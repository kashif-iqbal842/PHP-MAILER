<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Php Mail</title>
</head>
<body>
<form action="mail.php" method="post" enctype="multipart/form-data">
  First Name:
  <input type="text" name="fname"><br><br/>
  Last name:
  <input type="text" name="lname"><br><br>
    Email ID:
  <input type="text" name="email"><br><br>
    Mobile No:
  <input type="text" name="mobile"><br><br>
  <input type="submit" value="Submit">
</form>
</body>
</html>
